package com.ams.util;

import java.security.SecureRandom;
import jakarta.servlet.http.HttpSession;

/**
 * Minimal session-bound CSRF protection.
 *
 * One random token is generated per login session and stored as a session
 * attribute. Every state-changing form embeds it as a hidden field; every
 * *_action.jsp must call {@link #isValid} before doing anything with the
 * request, and reject the request (without touching the database) if the
 * token is missing or doesn't match.
 *
 * This is the standard "synchronizer token" pattern: simple, framework-free,
 * and sufficient for an internal admin tool like this one.
 */
public final class CsrfUtil {

    private static final String SESSION_KEY = "csrfToken";
    private static final SecureRandom RANDOM = new SecureRandom();

    private CsrfUtil() { }

    /**
     * Returns the CSRF token for this session, generating and storing a new
     * one if none exists yet. Call this from header.jsp so every protected
     * page (and therefore every form on it) has a token available.
     */
    public static String getOrCreateToken(HttpSession session) {
        String token = (String) session.getAttribute(SESSION_KEY);
        if (token == null) {
            token = generateToken();
            session.setAttribute(SESSION_KEY, token);
        }
        return token;
    }

    private static String generateToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16));
            sb.append(Character.forDigit(b & 0xF, 16));
        }
        return sb.toString();
    }

    /**
     * Validates a submitted token against the one stored in the session.
     * Uses a constant-time comparison to avoid leaking the real token
     * through response-timing differences.
     */
    public static boolean isValid(HttpSession session, String submittedToken) {
        if (session == null || submittedToken == null) return false;
        String real = (String) session.getAttribute(SESSION_KEY);
        if (real == null || real.length() != submittedToken.length()) return false;

        int diff = 0;
        for (int i = 0; i < real.length(); i++) {
            diff |= real.charAt(i) ^ submittedToken.charAt(i);
        }
        return diff == 0;
    }
}
