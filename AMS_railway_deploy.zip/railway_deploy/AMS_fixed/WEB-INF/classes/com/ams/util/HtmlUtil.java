package com.ams.util;

/**
 * Tiny HTML-escaping helper. The JSPs in this project print a lot of
 * user-supplied strings (asset names, employee names, remarks, etc.)
 * directly into HTML with <%= %>. esc() neutralizes the five characters
 * that matter for breaking out of HTML text/attribute context, so a value
 * like an asset name containing "<script>" renders as harmless text
 * instead of executing.
 *
 * Usage in a JSP: <%= esc(row.get("asset_name")) %>
 * (each page imports this statically: <%@ page import="static com.ams.util.HtmlUtil.esc" %>)
 */
public final class HtmlUtil {

    private HtmlUtil() { }

    public static String esc(Object value) {
        if (value == null) return "";
        String s = value.toString();
        StringBuilder out = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':  out.append("&amp;");  break;
                case '<':  out.append("&lt;");   break;
                case '>':  out.append("&gt;");   break;
                case '"':  out.append("&quot;"); break;
                case '\'': out.append("&#39;");  break;
                default:   out.append(c);
            }
        }
        return out.toString();
    }
}
