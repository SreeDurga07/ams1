package com.ams.util;

/**
 * Centralizes the "is this session an Admin" check used by every
 * *_action.jsp before it touches the database. Kept as a one-line helper
 * so the same logic (and the same definition of "Admin") is used
 * everywhere instead of being copy-pasted with the chance of drifting.
 */
public final class AuthUtil {

    private AuthUtil() { }

    public static boolean isAdmin(jakarta.servlet.http.HttpSession session) {
        if (session == null) return false;
        Object role = session.getAttribute("role");
        return "Admin".equals(role);
    }
}
