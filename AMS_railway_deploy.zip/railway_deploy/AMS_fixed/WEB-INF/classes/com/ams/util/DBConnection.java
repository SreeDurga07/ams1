package com.ams.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * Central JDBC connection helper for the Asset Management System.
 *
 * Connection settings are resolved in this order:
 *   1. Environment variables (DB_URL, DB_USER, DB_PASSWORD, DB_DRIVER) --
 *      set automatically by Railway (or any container host) when a MySQL
 *      service is attached, so no file edits are needed there.
 *   2. /WEB-INF/classes/db.properties -- used for local Tomcat deployments
 *      where editing a file is more convenient than setting env vars.
 *
 * Example db.properties (MySQL):
 *   db.driver=com.mysql.cj.jdbc.Driver
 *   db.url=jdbc:mysql://localhost:3306/ams_db?useSSL=false&serverTimezone=UTC
 *   db.user=ams_user
 *   db.password=ams_password
 *
 * Example db.properties (Oracle):
 *   db.driver=oracle.jdbc.driver.OracleDriver
 *   db.url=jdbc:oracle:thin:@localhost:1521:xe
 *   db.user=ams_user
 *   db.password=ams_password
 */
public class DBConnection {

    private static final Properties props = new Properties();
    private static boolean driverLoaded = false;
    private static boolean fileLoaded = false;

    private static synchronized void loadFileConfigIfNeeded() {
        if (fileLoaded) return;
        fileLoaded = true;
        try (InputStream in = DBConnection.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (Exception e) {
            // fall through -- env vars may still provide everything we need
        }
    }

    /**
     * Returns an environment variable if set and non-empty, otherwise the
     * given db.properties key, otherwise null.
     */
    private static String resolve(String envKey, String propsKey) {
        String fromEnv = System.getenv(envKey);
        if (fromEnv != null && !fromEnv.isEmpty()) return fromEnv;
        loadFileConfigIfNeeded();
        return props.getProperty(propsKey);
    }

    /**
     * Returns a new JDBC connection using environment variables if present,
     * otherwise the settings from db.properties. Callers are responsible
     * for closing the connection (use try-with-resources).
     */
    public static Connection getConnection() throws Exception {
        String driver   = resolve("DB_DRIVER",   "db.driver");
        String url      = resolve("DB_URL",      "db.url");
        String user     = resolve("DB_USER",     "db.user");
        String password = resolve("DB_PASSWORD", "db.password");

        if (driver == null) driver = "com.mysql.cj.jdbc.Driver";

        if (url == null) {
            throw new RuntimeException(
                "No database URL configured. Set the DB_URL environment variable, "
              + "or create WEB-INF/classes/db.properties with a db.url entry.");
        }

        if (!driverLoaded) {
            Class.forName(driver);
            driverLoaded = true;
        }
        return DriverManager.getConnection(url, user, password);
    }
}
