package com.ams.util;

/**
 * Thin wrapper around {@link BCrypt} used by the AMS login flow.
 *
 * Work factor 12 (the BCrypt default) is used for new hashes, which is a
 * reasonable balance of security and login latency as of 2026 hardware.
 * Increase WORK_FACTOR over time as hardware gets faster.
 */
public final class PasswordUtil {

    private static final int WORK_FACTOR = 12;

    private PasswordUtil() { }

    /** Hash a plaintext password for storage in the users.password column. */
    public static String hash(String plaintext) {
        return BCrypt.hashpw(plaintext, BCrypt.gensalt(WORK_FACTOR));
    }

    /** Check a plaintext password against a stored BCrypt hash. */
    public static boolean verify(String plaintext, String storedHash) {
        if (plaintext == null || storedHash == null || storedHash.isEmpty()) return false;
        try {
            return BCrypt.checkpw(plaintext, storedHash);
        } catch (IllegalArgumentException badHash) {
            // storedHash wasn't a valid bcrypt hash (e.g. legacy plaintext row)
            return false;
        }
    }

    /**
     * True if the given stored value looks like a bcrypt hash
     * ($2a$, $2b$ or $2y$ prefix) rather than legacy plaintext.
     * Used only to support a one-time migration path for old data.
     */
    public static boolean isBcryptHash(String stored) {
        return stored != null && stored.matches("^\\$2[aby]\\$\\d{2}\\$.{53}$");
    }
}
