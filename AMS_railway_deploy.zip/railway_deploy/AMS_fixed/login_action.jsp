<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.ams.util.DBConnection" %>
<%@ page import="com.ams.util.PasswordUtil" %>
<%
    String username = request.getParameter("username");
    String password = request.getParameter("password");
    String role      = request.getParameter("role");

    if (username == null) username = "";
    if (password == null) password = "";
    if (role == null) role = "User";

    boolean success = false;

    // Note: role is NOT part of the WHERE clause anymore. The account's role
    // is the source of truth; the login form's role selector is only used to
    // confirm against what's on file, so a stale/incorrect form selection
    // can't accidentally lock someone out (and can't be used to probe for
    // valid username/password pairs under the wrong role either, since we
    // still fail closed below if the selected role doesn't match).
    String sql = "SELECT u.user_id, u.username, u.password, u.full_name, u.role, u.status, "
                + "       e.employee_id, e.department "
                + "FROM users u "
                + "LEFT JOIN employees e ON e.employee_id = u.employee_id "
                + "WHERE u.username = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, username);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String storedHash = rs.getString("password");
                String actualRole = rs.getString("role");

                boolean passwordOk = PasswordUtil.verify(password, storedHash);
                boolean roleOk = actualRole.equals(role);
                boolean active = !"Inactive".equalsIgnoreCase(rs.getString("status"));

                if (passwordOk && roleOk && active) {
                    success = true;

                    session.setAttribute("userId",   rs.getInt("user_id"));
                    session.setAttribute("username", rs.getString("username"));
                    session.setAttribute("fullName", rs.getString("full_name"));
                    session.setAttribute("role",     actualRole);
                    session.setAttribute("employeeId", rs.getObject("employee_id"));
                    session.setAttribute("department", rs.getString("department"));

                    // update last login
                    try (PreparedStatement up = con.prepareStatement(
                            "UPDATE users SET last_login = NOW() WHERE user_id = ?")) {
                        up.setInt(1, rs.getInt("user_id"));
                        up.executeUpdate();
                    }

                    // audit trail
                    try (PreparedStatement log = con.prepareStatement(
                            "INSERT INTO audit_log (username, action, entity, entity_id, details) VALUES (?, 'LOGIN', 'USER', ?, 'User signed in')")) {
                        log.setString(1, rs.getString("username"));
                        log.setString(2, String.valueOf(rs.getInt("user_id")));
                        log.executeUpdate();
                    }
                }
            }
        }
    } catch (Exception ex) {
        // In production, log ex to a file instead of printing
        response.sendRedirect("index.jsp?error=1");
        return;
    }

    if (success) {
        response.sendRedirect("dashboard.jsp");
    } else {
        response.sendRedirect("index.jsp?error=1");
    }
%>
