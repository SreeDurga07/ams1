# Deploying AMS to Railway

This gets you a real public HTTPS URL for the Asset Management System,
using Railway's free trial credit, a Docker container (Tomcat + the app),
and Railway's managed MySQL plugin.

## What's in this folder

- `Dockerfile` -- builds Tomcat 10.1 + JDK 21, bundles the MySQL JDBC
  driver, and deploys `AMS_fixed/` as the web app at the domain root.
- `AMS_fixed/` -- the hardened AMS project (BCrypt auth, CSRF, role
  enforcement, output escaping -- see its own README.md for details).
- `.dockerignore` -- keeps stray files out of the build.

`AMS_fixed/WEB-INF/classes/com/ams/util/DBConnection.java` reads database
settings from environment variables first (`DB_URL`, `DB_USER`,
`DB_PASSWORD`, `DB_DRIVER`), falling back to `db.properties` only if those
aren't set. That's what makes this work on Railway without editing any
files -- you just set the right variables in Railway's dashboard.

---

## Step 1: Push this folder to GitHub

Railway deploys from a GitHub repo. If you don't already have one:

1. Create a new repository on GitHub (e.g. `ams-website`).
2. From this folder, run:
   ```bash
   git init
   git add .
   git commit -m "AMS hardened build for Railway"
   git branch -M main
   git remote add origin https://github.com/<your-username>/ams-website.git
   git push -u origin main
   ```
   (If you're not comfortable with git commands, GitHub Desktop or the
   "Add file > Upload files" button on a new repo's web page both work
   too -- just make sure `Dockerfile` ends up at the **root** of the repo,
   not nested inside another folder.)

## Step 2: Create a Railway project

1. Go to **https://railway.com** and sign up / log in with GitHub.
2. Click **New Project** -> **Deploy from GitHub repo**.
3. Authorize Railway to access your GitHub account if prompted, then pick
   the `ams-website` repo.
4. Railway will detect the `Dockerfile` and start a build automatically.
   Let it fail for now -- there's no database yet, so it won't be able
   to log in. We'll fix that in the next steps.

## Step 3: Add a MySQL database

1. On your project's canvas, click **+ New** (or right-click the canvas)
   -> **Database** -> **Add MySQL**.
2. Railway provisions a managed MySQL instance. Click into it once it's
   ready.

## Step 4: Load the schema into Railway's MySQL

You need to run `database/ams_schema.sql` against this new database.
Easiest way, using Railway's built-in **Data** tab:

1. Click the MySQL service -> **Data** tab -> there's usually a **Query**
   or **Connect** option that opens a SQL console in the browser.
2. Open `AMS_fixed/database/ams_schema.sql` from this project in a text
   editor, copy its entire contents, paste into the query console, and
   run it.

   *(Alternative: click the MySQL service -> **Variables** tab, copy the
   `MYSQLHOST`, `MYSQLPORT`, `MYSQLUSER`, `MYSQLPASSWORD`, `MYSQLDATABASE`
   values, and connect with MySQL Workbench using those -- Railway exposes
   a public host/port for external tools under **Settings -> Networking
   -> Public Networking** on the MySQL service if it's not connectable
   directly.)*

## Step 5: Connect the web service to MySQL

This is the step that's easy to get wrong, so follow it exactly.

1. Click on your **web service** (the one built from the Dockerfile, not
   the MySQL one) -> **Variables** tab.
2. Add these four variables. For each one, when you start typing `${{`
   Railway's autocomplete will suggest the MySQL service's variables --
   use that instead of typing values by hand, so they stay in sync if
   Railway ever rotates credentials:

   | Variable name  | Value                                                                 |
   |----------------|------------------------------------------------------------------------|
   | `DB_DRIVER`    | `com.mysql.cj.jdbc.Driver`                                            |
   | `DB_URL`       | `jdbc:mysql://${{MySQL.MYSQLHOST}}:${{MySQL.MYSQLPORT}}/${{MySQL.MYSQLDATABASE}}?useSSL=false&allowPublicKeyRetrieval=true` |
   | `DB_USER`      | `${{MySQL.MYSQLUSER}}`                                                 |
   | `DB_PASSWORD`  | `${{MySQL.MYSQLPASSWORD}}`                                            |

   (Replace `MySQL` in `${{MySQL....}}` with whatever your MySQL service
   is actually named in your project, if you renamed it -- Railway shows
   the right name in the autocomplete dropdown as you type `${{`.)

3. Click **Deploy** to apply the variables and trigger a new deployment
   of the web service.

## Step 6: Get your public URL

1. On the web service, go to **Settings -> Networking**.
2. Click **Generate Domain**. Railway gives you a URL like
   `https://ams-website-production.up.railway.app`.
3. Open it. You should see the AMS login page.
4. Log in with `admin` / `admin123` (or `kverma` / `user123` for the
   read-only User role) -- see `AMS_fixed/README.md` for details on
   changing these.

## Troubleshooting

- **Build fails on the `ADD` step for the MySQL driver jar**: Railway's
  build servers need outbound internet access to Maven Central, which
  they have by default. If this specific step fails, check Railway's
  build logs for the actual error -- it's usually transient and a retry
  (push an empty commit, or click **Redeploy**) fixes it.
- **App deploys but login always fails / 500 error**: almost always a
  `DB_URL`/`DB_USER`/`DB_PASSWORD` mismatch. Check the web service's
  **Deployments -> [latest] -> Logs** for a stack trace -- a JDBC
  connection error there will name the exact problem (wrong host,
  access denied, unknown database, etc).
- **"No database URL configured" error page**: the `DB_URL` variable
  isn't set on the *web service* (it's not enough to have it on the
  MySQL service -- it has to be referenced from the web service too,
  per Step 5).
- **Free trial credit runs out**: Railway's free trial is time/usage
  limited, not indefinite. Once it's exhausted, the service pauses
  until you add a payment method or it resets, depending on Railway's
  current plan terms -- check your dashboard for the current status.
